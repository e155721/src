library(R6)

# this function makes matrix for sequence alignment
makeMatrix <- function(seq1, seq2)
{
  len1 <- length(seq1)
  len2 <- length(seq2)
  x <- array(dim=c(len1, len2, 2),
             dimnames = list(seq1, seq2))
  return(x)
}

# this function initialises matrix
initializeMat <- function(x, p)
{
  len1 <- dim(x)[1]
  len2 <- dim(x)[2]
  
  g <- 0
  for (i in 1:len1) {
    x[i, 1, 1] <- g
    x[i, 1, 2] <- 1
    g <- g + p
  }
  
  g <- 0
  for (j in 1:len2) {
    x[1, j, 1] <- g
    x[1, j, 2] <- -1
    g = g + p
  }
  
  return(x)
}

s <- 
  R6Class("s",
          public = list(
            seq1 = NA,
            seq2 = NA,
            scoringMatrix = NA,
            initialize = function(seq1, seq2, scoringMatrix)
            {
              self$seq1 <- seq1
              self$seq2 <- seq2
              self$scoringMatrix <- scoringMatrix
            },
            get_score = function(i,j)
            {
              x <- y <- score <-  NA
              x <- self$seq1[i]
              y <- self$seq2[j]
              score <- self$scoringMatrix[x,y]
              return(score)
            }
          )
  )

# this function's aruments range are greater than equal 2
D <- function(x, i, j, p, s)
{
  d1 <- x[i-1, j-1, 1] + s$get_score(i, j)
  d2 <- x[i-1, j, 1] + p
  d3 <- x[i, j-1, 1] + p
  
  d <- list()
  d[[1]] <- max(d1, d2, d3)
  
  if (d[[1]] == d1) {
    d[[2]] <- 0 # (0,0)
  } else if (d[[1]] == d2) {
    d[[2]] <- 1 # (0,1)
  } else {
    d[[2]] <- -1 # (-1,0)
  }
  
  return(d)
}